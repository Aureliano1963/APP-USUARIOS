package com.example.modelo;

import java.io.Serializable;

public class Chat_asesoria implements Serializable {
    public int id_chat_asesoria;
    public String fecha_inicio_asesoria;
    public String hora_inicio_asesoria;
    public String fecha_cierre_asesoria;
    public String hora_cierra_chat_asesoria;
    public int administrador_chat_asesoria;
    public int usuario_chat_asesoria;
    public int estado_cerrado;
    public String tiempo_sesion_chat_asesoria;
    public int especializacion_chat_asesoria;
    public String ultima_fecha_administrador_chat_asesoria;
    public String ultima_hora_administrador_chat_asesoria;
    public String ultimo_mensaje_administrador_chat_asesoria;
    public String ultima_fecha_usuario_chat_asesoria;
    public String ultima_hora_usuario_chat_asesoria;
    public String ultimo_mensaje_usuario_chat_asesoria;
    public String ultima_fecha_vista_administrador_chat_asesoria;
    public String ultima_hora_vista_administrador_chat_asesoria;
    public String ultima_fecha_vista_usuario_chat_asesoria;
    public String ultima_hora_vista_usuario_chat_asesoria;
    public String ultimo_mensaje_chat_asesoria;
    public String ultima_fecha_chat_asesoria;
    public String ultima_hora_chat_asesoria;
    public int usuario_respondio_chat_asesoria;
    public String usuario;
    public String administrador;
    public String especialidad;
    public boolean mensajeNuevo;
}
