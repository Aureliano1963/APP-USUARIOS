package com.example.modelo;

import java.io.Serializable;

public class Noticia implements Serializable {
    public int id_notiticia;
    public int id_generacion_noticia;
    public String titulo_noticia;
    public String contenido_noticia;
    public int num_imagenes_noticia;
    public String fecha_registro_noticia;
    public String hora_registro_noticia;
    public int tipo_creacion_noticia;
    public int numero_visistas_noticia;
    public int administrador_noticia;
    public int categoria_noticia_manual_noticia;
    public int numero_me_gusta;
    public String json_imagenes;
}
