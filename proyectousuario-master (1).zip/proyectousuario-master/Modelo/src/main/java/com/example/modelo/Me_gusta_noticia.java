package com.example.modelo;

public class Me_gusta_noticia {
    public int id_me_gusta_noticia;
    public int usuario_me_gusta_noticia;
    public int noticia_me_gusta_noticia;
}
