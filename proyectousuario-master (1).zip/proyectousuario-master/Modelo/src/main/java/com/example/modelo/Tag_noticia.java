package com.example.modelo;

public class Tag_noticia {
    public int id_tag_noticia;
    public String nombre_tag_noticia;
    public int numero_usos;
    public int noticia_id_notiticia;
}
