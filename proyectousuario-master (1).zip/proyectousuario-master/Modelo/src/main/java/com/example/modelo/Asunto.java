package com.example.modelo;

public class Asunto {
    public int id_asunto;
    public String nombre_asunto;
    public int numero_alertas_tempranas_asunto;
    public int numero_alertas_tempranas_atendidas_asunto;
    public int numero_alertas_tempranas_no_atendidas_asunto;
    public int numero_alertas_tempranas_por_primera_infancia_asunto;
    public int numero_alertas_tempranas_por_infancia_asunto;
    public int numero_alertas_tempranas_por_adolecencia_asunto;
    public int numero_alertas_tempranas_por_juventud_asunto;
    public int numero_alertas_tempranas_por_adultez_asunto;
    public int numero_alertas_tempranas_por_mayor_asunto;
    public int numero_alertas_tempranas_por_primera_m_infancia_asunto;
    public int numero_alertas_tempranas_por_infancia_m_asunto;
    public int numero_alertas_tempranas_por_adolecencia_m_asunto;
    public int numero_alertas_tempranas_por_juventud_m_asunto;
    public int numero_alertas_tempranas_por_adultez_m_asunto;
    public int numero_alertas_tempranas_por_mayor_m_asunto;
    public int numero_alertas_tempranas_por_primera_f_infancia_asunto;
    public int numero_alertas_tempranas_por_infancia_f_asunto;
    public int numero_alertas_tempranas_por_adolecencia_f_asunto;
    public int numero_alertas_tempranas_por_juventud_f_asunto;
    public int numero_alertas_tempranas_por_adultez_f_asunto;
    public int numero_alertas_tempranas_por_mayor_f_asunto;
}
