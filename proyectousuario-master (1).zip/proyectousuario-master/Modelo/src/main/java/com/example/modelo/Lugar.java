package com.example.modelo;

public class Lugar {
    public int id_lugar;
    public String nombre_lugar;
    public float longitud_lugar;
    public float latitud_lugar;
    public String direccion_lugar;
    public int numero_visitas_lugar;
    public int numero_visitas_por_primera_infancia_lugar;
    public int numero_visitas_por_infancia_lugar;
    public int numero_visitas_por_adolecencia_lugar;
    public int numero_visitas_por_juventud_lugar;
    public int numero_visitas_por_adultez_lugar;
    public int numero_visitas_por_mayor_lugar;
    public int numero_visitas_por_primera_m_infancia_lugar;
    public int numero_visitas_por_infancia_m_lugar;
    public int numero_visitas_por_adolecencia_m_lugar;
    public int numero_visitas_por_juventud_m_lugar;
    public int numero_visitas_por_adultez_m_lugar;
    public int numero_visitas_por_mayor_m_lugar;
    public int numero_visitas_por_primera_f_infancia_lugar;
    public int numero_visitas_por_infancia_f_lugar;
    public int numero_visitas_por_adolecencia_f_lugar;
    public int numero_visitas_por_juventud_f_lugar;
    public int numero_visitas_por_adultez_f_lugar;
    public int numero_visitas_por_mayor_f_lugar;
}
