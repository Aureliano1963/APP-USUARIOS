package com.example.modelo;

public class Especialidad {
    public int id_especialidad;
    public String nombre_especialidad;
    public int numero_asignados_especilidad;
    public int numero_chat_asesoria_especialidad;
    public int numero_chat_asesoria_primera_infancia_especialidad;
    public int numero_chat_asesoria_infancia_especialidad;
    public int numero_chat_asesoria_adolecencia_especialidad;
    public int numero_chat_asesoria_juventud_especialidad;
    public int numero_chat_asesoria_adultez_especialidad;
    public int numero_chat_asesoria_mayor_especialidad;
    public int numero_chat_asesoria_primera_infancia_m_especialidad;
    public int numero_chat_asesoria_infancia_m_especialidad;
    public int numero_chat_asesoria_adolecencia_m_especialidad;
    public int numero_chat_asesoria_juventud_m_especialidad;
    public int numero_chat_asesoria_adultez_m_especialidad;
    public int numero_chat_asesoria_mayor_m_especialidad;
    public int numero_chat_asesoria_primera_infancia_f_especialidad;
    public int numero_chat_asesoria_infancia_f_especialidad;
    public int numero_chat_asesoria_adolecencia_f_especialidad;
    public int numero_chat_asesoria_juventud_f_especialidad;
    public int numero_chat_asesoria_adultez_f_especialidad;
    public int numero_chat_asesoria_mayor_f_especialidad;
}
