package com.example.modelo;

public class Boton {
    public int id_boton;
    public String nombre_boton_boton;
    public int id_boton_en_aplicacion_boton;
    public int numero_veces_precionado_boton;
    public int numero_veces_presionados_por_primera_infancia_boton;
    public int numero_veces_presionados_por_infancia_boton;
    public int numero_veces_presionados_por_adolecencia_boton;
    public int numero_veces_presionado_por_juventud_boton;
    public int numero_veces_presionado_por_adultez_boton;
    public int numero_veces_presionado_por_mayor_boton;
    public int numero_veces_presionados_por_primera_infancia_m_boton;
    public int numero_veces_presionados_por_primera_infancia_f_boton;
    public int numero_veces_presionados_por_infancia_m_boton;
    public int numero_veces_presionados_por_infancia_f_boton;
    public int numero_veces_presionados_por_adolecencia_m_boton;
    public int numero_veces_presionados_por_adolecencia_f_boton;
    public int numero_veces_presionado_por_juventud_m_boton;
    public int numero_veces_presionado_por_juventud_f_boton;
    public int numero_veces_presionado_por_adultez_m_boton;
    public int numero_veces_presionado_por_adultez_f_boton;
    public int numero_veces_presionado_por_mayor_m_boton;
    public int numero_veces_presionado_por_mayor_f_boton;
}
