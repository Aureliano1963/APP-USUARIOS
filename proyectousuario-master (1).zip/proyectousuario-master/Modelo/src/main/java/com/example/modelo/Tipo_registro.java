package com.example.modelo;

public class Tipo_registro {
    public int id_tipo_registro;
    public String nombre_tipo_registro;
    public String fecha_registro_tipo_registro;
    public String hora_registro_tipo_registro;
}
