package com.example.modelo;

public class Categoria_noticia_manual {
    public int id_categoria_noticia_manual;
    public String nombre_categoria_noticia;
    public int numero_noticias_categoria_noticia;
    public int numero_noticias_no_visitadas_categoria_noticia;
    public int numero_visitas_categoria_noticia_manual;
    public int numero_visitas_por_primera_infancia_categoria_noticia;
    public int numero_visitas_por_infancia_categoria_noticia;
    public int numero_visitas_por_adolecencia_categoria_noticia;
    public int numero_visitas_por_juventud_categoria_noticia;
    public int numero_visitas_por_adultez_categoria_noticia;
    public int numero_visitas_por_mayor_categoria_noticia;
    public int numero_visitas_por_primera_m_infancia_categoria_noticia;
    public int numero_visitas_por_infancia_m_categoria_noticia;
    public int numero_visitas_por_adolecencia_m_categoria_noticia;
    public int numero_visitas_por_juventud_m_categoria_noticia;
    public int numero_visitas_por_adultez_m_categoria_noticia;
    public int numero_visitas_por_mayor_m_categoria_noticia;
    public int numero_visitas_por_primera_f_infancia_categoria_noticia;
    public int numero_visitas_por_infancia_f_categoria_noticia;
    public int numero_visitas_por_adolecencia_f_categoria_noticia;
    public int numero_visitas_por_juventud_f_categoria_noticia;
    public int numero_visitas_por_adultez_f_categoria_noticia;
    public int numero_visitas_por_mayor_f_categoria_noticia;
}
