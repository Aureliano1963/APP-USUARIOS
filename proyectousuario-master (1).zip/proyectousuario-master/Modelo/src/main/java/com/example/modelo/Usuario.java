package com.example.modelo;

public class Usuario {
    public int id_usuario;
    public String numero_identificacion_usuario;
    public String nombres_usuario;
    public String apellidos_usuario;
    public String direccion_usuario;
    public String telefono_usuario;
    public int sexo_usuario;
    public String fecha_nacimiento;
    public String correo_usuario;
    public String nombre_cuenta_usuario;
    public String contrasena_usuario;
    public String foto_perfil_usuario;
    public String foto_perfil_anterior;
    public String token;
    public int tipo_cuenta;
}
