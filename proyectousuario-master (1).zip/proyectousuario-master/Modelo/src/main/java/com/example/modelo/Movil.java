package com.example.modelo;

public class Movil {
    public String imei;
    public String modelo_movil;
    public String fecha_registro_movil;
    public String hora_registro_movil;
}
