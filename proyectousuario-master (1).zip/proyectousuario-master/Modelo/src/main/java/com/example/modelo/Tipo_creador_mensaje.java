package com.example.modelo;

public class Tipo_creador_mensaje {
    public int id_tipo_creador;
    public String nombre_tipo_creador;
}
