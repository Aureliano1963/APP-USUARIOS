package com.example.modelo;

public class Administrador
{
    public int id_administrador;
    public int tipo_administrador;
    public String nombre_cuenta_administrador;
    public String contrasena_administrador;
    public String nombres_administrador;
    public String apellidos_administrador;
    public String fecha_nacimiento_administrador;
    public int sexo_administrador;
    public int estado_administrador;
    public String fecha_registro_administrador;
    public String hora_registro_administrador;
    public String url_foto_perfil_administrador;
    public int numero_asesorias_dadas_administrador;
    public int numero_asesorias_dadas_primera_infancia_administrador;
    public int numero_asesorias_dadas_infancia_administrador;
    public int numero_asesorias_dadas_adolecencia_administrador;
    public int numero_asesorias_dadas_juventud_administrador;
    public int numero_asesorias_dadas_adultez_administrador;
    public int numero_asesorias_dadas_mayor_administrador;
    public int numero_asesorias_dadas_primera_m_infancia_administrador;
    public int numero_asesorias_dadas_infancia_m_administrador;
    public int numero_asesorias_dadas_adolecencia_m_administrador;
    public int numero_asesorias_dadas_juventud_m_administrador;
    public int numero_asesorias_dadas_adultez_m_administrador;
    public int numero_asesorias_dadas_mayor_m_administrador;
    public int numero_asesorias_dadas_primera_f_infancia_administrador;
    public int numero_asesorias_dadas_infancia_f_administrador;
    public int numero_asesorias_dadas_adolecencia_f_administrador;
    public int numero_asesorias_dadas_juventud_f_administrador;
    public int numero_asesorias_dadas_adultez_f_administrador;
    public int numero_asesorias_dadas_mayor_f_administrador;
}
