package com.example.modelo;

public class Mensaje_chat_asesoria {
    public int id_mensaje_chat_asesoria;
    public String fecha_envio_mensaje_chat_asesoria;
    public String hora_envio_mensaje_asesoria;
    public String contenido_mensaje_chat_asesoria;
    public int chat_mensaje_chat_asesoria;
    public int id_creador_mensaje_chat_asesoria;
    public int tipo_creador_mensaje_chat_asesoria;
}
