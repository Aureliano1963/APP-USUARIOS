package com.example.modelo;

public class Alerta_temprana
{
    public int id_alerta_temprana;
    public int asunto_alerta_temprana;
    public String descripcion_alerta_temprana;
    public String fecha_alerta_temprana;
    public String hora_alerta_temprana;
    public int usuario_alerta_temprana;
    public int administrador_alerta_temprana;
    public int estado_visto;
    public int numero_visitas;
    public int estado_atendido;
    public int atendido_por;
    public String asunto;
    public String direccion_alerta_temprana;
    public String numero_telefono_alerta_temprana;
}
