package com.example.modelo;

public class Accion
{
    public int id_accion;
    public int tipo_accion;
    public int accion;
    public String fecha_accion;
    public String hora_accion;
    public int id_generador_accion;
    public int id_entidad_accion;
}
