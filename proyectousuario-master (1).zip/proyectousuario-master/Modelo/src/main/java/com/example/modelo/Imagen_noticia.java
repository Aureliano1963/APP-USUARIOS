package com.example.modelo;

import java.io.Serializable;

public class Imagen_noticia implements Serializable {
    public int id_imagen_noticia;
    public String url_imagen_noticia;
    public String fecha_registro_imagen_noticia;
    public String hora_registro_imagen_noticia;
    public int noticia_imagen_noticia;
}
