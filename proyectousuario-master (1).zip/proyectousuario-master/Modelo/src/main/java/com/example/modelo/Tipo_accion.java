package com.example.modelo;

public class Tipo_accion {
    public int id_tipo_accion;
    public String nombre_tipo_accion;
    public int numero_acciones_por_primera_infancia_tipo_accion;
    public int numero_acciones_por_infancia_tipo_accion;
    public int numero_acciones_por_adolecencia_tipo_accion;
    public int numero_acciones_por_juventud_tipo_accion;
    public int numero_acciones_por_adultez_tipo_accion;
    public int numero_acciones_por_mayor_tipo_accion;
    public int numero_acciones_por_primera_m_infancia_tipo_accion;
    public int numero_acciones_por_infancia_m_tipo_accion;
    public int numero_acciones_por_adolecencia_m_tipo_accion;
    public int numero_acciones_por_juventud_m_tipo_accion;
    public int numero_acciones_por_adultez_m_tipo_accion;
    public int numero_acciones_por_mayor_m_tipo_accion;
    public int numero_acciones_por_primera_f_infancia_tipo_accion;
    public int numero_acciones_por_infancia_f_tipo_accion;
    public int numero_acciones_por_adolecencia_f_tipo_accion;
    public int numero_acciones_por_juventud_f_tipo_accion;
    public int numero_acciones_por_adultez_f_tipo_accion;
    public int numero_acciones_por_mayor_f_tipo_accion;
}
