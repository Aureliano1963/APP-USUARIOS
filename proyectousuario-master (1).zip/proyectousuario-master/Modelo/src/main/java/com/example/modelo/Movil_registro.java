package com.example.modelo;

public class Movil_registro {
    public int id_movil_registro;
    public String fecha_movil_registro;
    public String hora_movil_registro;
    public String imei_movil_registro;
    public int id_registrado_movil_registro;
    public int tipo_registro_movil_registro;
}
