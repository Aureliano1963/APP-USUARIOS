package com.example.modelo;

public class Pagina {
    public int id_pagina;
    public String url_pagina;
    public int numero_visitas_pagina;
    public int numero_visitas_por_primera_infancia_pagina;
    public int numero_visitas_por_infancia_pagina;
    public int numero_visitas_por_adolecencia_pagina;
    public int numero_visitas_por_juventud_pagina;
    public int numero_visitas_por_adultez_pagina;
    public int numero_visitas_por_mayor_pagina;
    public int numero_visitas_por_primera_m_infancia_pagina;
    public int  numero_visitas_por_infancia_m_pagina;
    public int numero_visitas_por_adolecencia_m_pagina;
    public int numero_visitas_por_juventud_m_pagina;
    public int numero_visitas_por_adultez_m_pagina;
    public int numero_visitas_por_mayor_m_pagina;
    public int numero_visitas_por_primera_f_infancia_pagina;
    public int numero_visitas_por_infancia_f_pagina;
    public int numero_visitas_por_adolecencia_f_pagina;
    public int numero_visitas_por_juventud_f_pagina;
    public int numero_visitas_por_adultez_f_pagina;
    public int numero_visitas_por_mayor_f_pagina;
}
