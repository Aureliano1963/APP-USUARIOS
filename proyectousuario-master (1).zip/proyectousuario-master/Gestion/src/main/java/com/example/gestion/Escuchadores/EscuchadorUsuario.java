package com.example.gestion.Escuchadores;

import com.example.modelo.Usuario;

public interface EscuchadorUsuario {
    public void usuarioCambiado(Usuario usuario);
}
