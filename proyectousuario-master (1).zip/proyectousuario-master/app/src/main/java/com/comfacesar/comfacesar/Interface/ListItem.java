package com.comfacesar.comfacesar.Interface;

public interface ListItem {
    int SEXUALIDAD = 1;
    int EMBARAZO = 2;
    int MALTRATO = 3;
    int IDENTDAD = 4;
    int EMFERMEDADES_SEXUALES = 5;

    //metodo retorna que tipo de item es
    int getListItemType();
}
